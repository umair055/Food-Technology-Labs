import { configureStore } from '@reduxjs/toolkit';

import authReducer from './slices/authSlice';


export const store = configureStore({
  reducer: {
    auth: authReducer,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      immutableCheck: false,
      serializableCheck: false,
    }),
})